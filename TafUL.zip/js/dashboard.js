function openCreate() {
  document.getElementById("createModal").classList.add("show");
}

function closeCreate() {
  document.getElementById("createModal").classList.remove("show");
}

document.getElementById("createModal").addEventListener("click", function (e) {
  if (e.target === this) {
    closeCreate();
  }
});
